package com.example.facture.Controllers;

import com.example.facture.Controllers.dto.InvoiceRequestDto;
import com.example.facture.Models.Invoice;
import com.example.facture.Services.InvoiceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    InvoiceService invoiceService;

    InvoiceController(InvoiceService invoiceService){
        this.invoiceService = invoiceService;
    }

    @GetMapping
    List<Invoice> get(){
        return invoiceService.get();
    }

    @GetMapping("/{invoiceId}")
    Optional<Invoice> getById(@PathVariable(name = "invoiceId") Long id){
        return invoiceService.getById(id);
    }

    @PostMapping
    ResponseEntity<Map<String, Object>> create(final @RequestBody InvoiceRequestDto invoiceRequestDto){
        Invoice invoiceToCreate = new Invoice();

        invoiceToCreate.setNumber(invoiceRequestDto.getNumber());
        invoiceToCreate.setDate(invoiceRequestDto.getDate());
        invoiceToCreate.setGrandtotal(invoiceRequestDto.getGrandtotal());
        invoiceToCreate.setCreatedAt(LocalDateTime.now());

        invoiceService.create(invoiceToCreate);

        Map<String, Object> responses = new HashMap<>();
        responses.put("created", "true");

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{invoiceId}")
    ResponseEntity<Map<String, Object>> delete(@PathVariable Long invoiceId){
        invoiceService.delete(invoiceId);

        Map<String, Object> responses = new HashMap<>();
        responses.put("deleted", "true");

        return ResponseEntity.ok(responses);
    }
}
