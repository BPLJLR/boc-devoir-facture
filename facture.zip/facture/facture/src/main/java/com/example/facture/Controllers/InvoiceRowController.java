package com.example.facture.Controllers;

import com.example.facture.Models.InvoiceRow;
import com.example.facture.Controllers.dto.InvoiceRowRequestDto;
import com.example.facture.Services.InvoiceRowService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/invoicerows")
public class InvoiceRowController {

    InvoiceRowService invoiceRowService;

    InvoiceRowController(InvoiceRowService invoiceRowService){
        this.invoiceRowService = invoiceRowService;
    }

    @GetMapping
    List<InvoiceRow> get(){
        return invoiceRowService.get();
    }

    @GetMapping("/{invoiceRowId}")
    Optional<InvoiceRow> getById(@PathVariable(name = "invoiceRowId") Long id){
        return invoiceRowService.getById(id);
    }

    @PostMapping
    ResponseEntity<Map<String, Object>> create(final @RequestBody InvoiceRowRequestDto invoiceRowRequestDto){
        InvoiceRow invoiceRowToCreate = new InvoiceRow();

        invoiceRowToCreate.setQty(invoiceRowRequestDto.getQty());
        invoiceRowToCreate.setPrice(invoiceRowRequestDto.getPrice());
        invoiceRowToCreate.setInvoiceId(invoiceRowRequestDto.getInvoiceId());
        invoiceRowToCreate.setProductId(invoiceRowRequestDto.getProductId());
        invoiceRowToCreate.setCreatedAt(LocalDateTime.now());

        invoiceRowService.create(invoiceRowToCreate);

        Map<String, Object> responses = new HashMap<>();
        responses.put("created", "true");

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{invoiceRowId}")
    ResponseEntity<Map<String, Object>> delete(@PathVariable Long invoiceRowId){
        invoiceRowService.delete(invoiceRowId);

        Map<String, Object> responses = new HashMap<>();
        responses.put("deleted", "true");

        return ResponseEntity.ok(responses);
    }
}

