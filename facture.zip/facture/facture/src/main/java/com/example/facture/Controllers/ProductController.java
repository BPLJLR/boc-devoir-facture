package com.example.facture.Controllers;

import com.example.facture.Controllers.dto.InvoiceRequestDto;
import com.example.facture.Controllers.dto.ProductRequestDto;
import com.example.facture.Models.Invoice;
import com.example.facture.Models.Product;
import com.example.facture.Services.InvoiceService;
import com.example.facture.Services.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    ProductService productService;

    ProductController(ProductService productService){
        this.productService = productService;
    }

    @GetMapping
    List<Product> get(){
        return productService.get();
    }

    @GetMapping("/{productId}")
    Optional<Product> getById(@PathVariable(name = "productId") Long id){
        return productService.getById(id);
    }

    @PostMapping
    ResponseEntity<Map<String, Object>> create(final @RequestBody ProductRequestDto productRequestDto){
        Product productToCreate = new Product();

        productToCreate.setRef(productRequestDto.getRef());
        productToCreate.setName(productRequestDto.getName());
        productToCreate.setDescription(productRequestDto.getDescription());
        productToCreate.setCreatedAt(LocalDateTime.now());

        productService.create(productToCreate);

        Map<String, Object> responses = new HashMap<>();
        responses.put("created", "true");

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/{productId}")
    ResponseEntity<Map<String, Object>> delete(@PathVariable Long productId){
        productService.delete(productId);

        Map<String, Object> responses = new HashMap<>();
        responses.put("deleted", "true");

        return ResponseEntity.ok(responses);
    }
}
