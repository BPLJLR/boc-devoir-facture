package com.example.facture.Controllers.dto;

import java.sql.Date;
import java.time.LocalDateTime;

public class InvoiceRequestDto {

    //Long id, String number, Date date, Float grandtotal, LocalDateTime createdAt
    private String number;

    private Date date;

    private Float grandtotal;

    private LocalDateTime createdAt;



    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Float getGrandtotal() {
        return grandtotal;
    }

    public void setGrandtotal(Float grandtotal) {
        this.grandtotal = grandtotal;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
