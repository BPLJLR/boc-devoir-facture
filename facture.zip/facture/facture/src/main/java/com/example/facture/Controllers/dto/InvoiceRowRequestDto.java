package com.example.facture.Controllers.dto;

import java.sql.Date;
import java.time.LocalDateTime;

public class InvoiceRowRequestDto {

    //Long id, Long qty, float price, float amount, Long productId, Long invoiceId, LocalDateTime createdAt
    private Long qty;

    private float price;

    private float amount;

    private Long productId;

    private Long invoiceId;

    private LocalDateTime createdAt;



    public Long getQty() {
        return qty;
    }

    public void setQty(Long qty) {
        this.qty = qty;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
