package com.example.facture.Controllers.dto;

import java.sql.Date;
import java.time.LocalDateTime;

public class ProductRequestDto {

    //Long id, String ref, String name, String description, LocalDateTime createdAt
    private String ref;

    private String name;

    private String description;

    private LocalDateTime createdAt;



    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
