package com.example.facture;

import com.example.facture.Models.Invoice;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactureApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactureApiApplication.class, args);
	}

}
