package com.example.facture.Models;

import jakarta.persistence.*;
//import java.sql.Date;
import java.time.LocalDateTime;

@Entity
@Table(name = "invoicerows")

public class InvoiceRow {
    private Long id;
    private Long qty;
    private float price;
    private float amount;
    private Long productId;
    private Long invoiceId;
    private LocalDateTime createdAt;

    @ManyToOne
    @JoinColumn(name = "invoice_id")
    private Invoice invoice;
    // -- 1 Facture => 200 Lignes de facture
    // -- 1 ligne de facture => 1 Facture


    public InvoiceRow(){
    }

    public InvoiceRow(Long id, Long qty, float price, float amount, Long productId, Long invoiceId, LocalDateTime createdAt) {
        this.id = id;
        this.qty = qty;
        this.price = price;
        this.amount = amount;
        this.productId = productId;
        this.invoiceId = invoiceId;
        this.createdAt = createdAt;
    }


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getQty() {
        return qty;
    }

    public void setQty(Long qty) {
        this.qty = qty;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }


    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
