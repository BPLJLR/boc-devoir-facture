package com.example.facture.Repositories;

import com.example.facture.Models.InvoiceRow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InvoiceRowRepository extends JpaRepository<InvoiceRow, Long> {
}
