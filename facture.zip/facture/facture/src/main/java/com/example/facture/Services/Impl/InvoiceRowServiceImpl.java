package com.example.facture.Services.Impl;

import com.example.facture.Models.InvoiceRow;
import com.example.facture.Repositories.InvoiceRowRepository;
import com.example.facture.Services.InvoiceRowService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InvoiceRowServiceImpl implements InvoiceRowService {

    @Autowired
    InvoiceRowRepository invoiceRowRepository;

    @Override
    public void create(InvoiceRow invoiceRow) {
        invoiceRowRepository.save(invoiceRow);
    }

    @Override
    public Optional<InvoiceRow> getById(Long id) {
        return invoiceRowRepository.findById(id);
    }

    @Override
    public List<InvoiceRow> get() {
        return invoiceRowRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Optional<InvoiceRow> studentToDelete = getById(id);
        invoiceRowRepository.delete(studentToDelete.get());
    }

    @Override
    public Optional<InvoiceRow> update(InvoiceRow invoiceRow) {
        invoiceRowRepository.save(invoiceRow);
        return Optional.empty();
    }
}
