package com.example.facture.Services.Impl;

import com.example.facture.Models.Invoice;
import com.example.facture.Repositories.InvoiceRepository;
import com.example.facture.Services.InvoiceService;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public class InvoiceServiceImpl implements InvoiceService {

    @Autowired
    InvoiceRepository invoiceRepository;

    @Override
    public void create(Invoice invoice) {
        invoiceRepository.save(invoice);
    }

    @Override
    public Optional<Invoice> getById(Long id) {
        return invoiceRepository.findById(id);
    }

    @Override
    public List<Invoice> get() {
        return invoiceRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Optional<Invoice> studentToDelete = getById(id);
        invoiceRepository.delete(studentToDelete.get());
    }

    @Override
    public Optional<Invoice> update(Invoice invoice) {
        invoiceRepository.save(invoice);
        return Optional.empty();
    }
}
