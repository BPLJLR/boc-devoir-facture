package com.example.facture.Services.Impl;

import com.example.facture.Models.Product;
import com.example.facture.Repositories.ProductRepository;
import com.example.facture.Services.ProductService;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public class ProductServiceImpl implements ProductService  {

    @Autowired
    ProductRepository productRepository;

    @Override
    public void create(Product product) {
        productRepository.save(product);
    }

    @Override
    public Optional<Product> getById(Long id) {
        return productRepository.findById(id);
    }

    @Override
    public List<Product> get() {
        return productRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        Optional<Product> studentToDelete = getById(id);
        productRepository.delete(studentToDelete.get());
    }

    @Override
    public Optional<Product> update(Product product) {
        productRepository.save(product);
        return Optional.empty();
    }
}
