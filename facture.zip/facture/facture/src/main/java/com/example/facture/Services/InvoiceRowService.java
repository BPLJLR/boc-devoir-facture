package com.example.facture.Services;

import com.example.facture.Models.Invoice;
import com.example.facture.Models.InvoiceRow;

import java.util.List;
import java.util.Optional;

public interface InvoiceRowService {
    void create(InvoiceRow invoiceRow);

    Optional<InvoiceRow> getById(Long id);

    List<InvoiceRow> get();

    void delete(Long id);

    Optional<InvoiceRow> update(InvoiceRow invoiceRow);
}