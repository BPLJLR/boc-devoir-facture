package com.example.facture.Services;

import com.example.facture.Models.Invoice;
import com.example.facture.Models.InvoiceRow;

import java.util.List;
import java.util.Optional;

public interface InvoiceService {
    void create(Invoice invoice);

    Optional<Invoice> getById(Long id);

    List<Invoice> get();

    void delete(Long id);

    Optional<Invoice> update(Invoice invoice);
}
