--Long id, String number, Date date, Float grandtotal, LocalDateTime createdAt
INSERT INTO invoices (id, number, date, grandtotal, created_at)
VALUES (10, 'ABC123', '2023-01-01', '30.0', now());

--Long id, Long qty, float price, float amount, Long productId, Long invoiceId, LocalDateTime createdAt
INSERT INTO invoicerows (id, qty, price, amount, productId, invoiceId, created_at)
VALUES (101, 2, 12.0, 24.0, 10, 700, now());

--Long id, String ref, String name, String description, LocalDateTime createdAt
INSERT INTO products (id, ref, name, description, created_at)
VALUES (700, '22-AZE-789', 'Xiaomi Redmi 10 Pro', 'Blabla...', now());
